clear all;
clc;
close all;

proc_speed_data;

P = prec;

lb = alpha/s_max;
ub = alpha/s_min;

% funkcia spotrebovanej energie
E = @(tau,eta) sum(tau + alpha + (alpha.^2).*eta + (alpha.^3).*(eta.^2));

%parameter lambda
lambda = 0.005;

%zavedieme eta = 1/tau kedze matlab nevie ze 1/tau je kvx
%optimalizacna uloha
cvx_begin sdp
cvx_solver sedumi
    variable tau(n)
    variable eta(n) 
    variable t(n) 
    minimize(norm(t,Inf) + lambda*E(tau,eta))
    subject to
        t >= ones(n,1)*norm(tau,Inf);
        t <= ones(n,1)*sum(tau);
        tau >= alpha/s_max;
        tau <= alpha/s_min;
        eta <= s_max*(1./alpha);
        eta >= s_min*(1./alpha);
        for j=1:m
            t(P(j,1)) +  tau(P(j,2)) - t(P(j,2)) <= 0;
        end
        % nahradime eta*tau=1 zrelaxovanim tohto ohranicenia
        for i=1:n
        [[eta(i), 1]; [1, tau(i)]]>=0;
        end
cvx_end

% %Vysledky
% tau
% t
% 1./eta
alpha./tau
% norm(t,inf)
% E(tau,eta)
% norm(t,Inf) + lambda*E(tau,eta)

%% riesenie pri rovnakej rychlosti
cvx_begin sdp
cvx_solver sedumi
    variable tau1(n)
    variable eta1(n) 
    variable t1(n)
    variable s(1)
    minimize(norm(t1,Inf) + lambda*E(tau1,eta1))
    subject to
        t1 >= ones(n,1)*norm(tau1,Inf);
        t1 <= ones(n,1)*sum(tau1);
        tau1 >= alpha/s_max;
        tau1 <= alpha/s_min;
        eta1 <= s_max*(1./alpha);
        eta1 >= s_min*(1./alpha);
        s == alpha.*eta1;
        s >= s_min;
        s <= s_max;
        for j=1:m
            t1(P(j,1)) +  tau1(P(j,2)) - t1(P(j,2)) <= 0;
        end
        for i=1:n
        [[eta1(i), 1]; [1, tau1(i)]]>=0;
        [[s, sqrt(alpha(i))]; [sqrt(alpha(i)), tau1(i)]]>=0;
        end
cvx_end

% %Vysledky
% tau1
% t1
% 1./eta1
s
% norm(t1,inf)
% E(tau1,eta1)
% norm(t1,Inf) + lambda*E(tau1,eta1)

h = msgbox('Now you can get yourself a coffee, the optimization will take 2-3 minutes :)');
%% obrazky

lambda1 = logspace(-3,-1,100);
%lambda1 = logspace(-2,-0,100);
f11 = [];
f12 = [];
f13 = [];

f21 = [];
f22 = [];
f23 = [];

for k=1:length(lambda1)
    cvx_begin sdp quiet
    cvx_solver sedumi
        variable tau(n)
        variable eta(n) 
        variable t(n) 
        minimize(norm(t,Inf) + lambda1(k)*E(tau,eta))
        subject to
            t >= ones(n,1)*norm(tau,Inf);
            t <= ones(n,1)*sum(tau);
            tau >= alpha/s_max;
            tau <= alpha/s_min;
            eta <= s_max*(1./alpha);
            eta >= s_min*(1./alpha);
            for j=1:m
                t(P(j,1)) +  tau(P(j,2)) - t(P(j,2)) <= 0;
            end
            % nahradime eta*tau=1 zrelaxovanim tohto ohranicenia
            for i=1:n
            [[eta(i), 1]; [1, tau(i)]]>=0;
            end
    cvx_end
    f11 = [f11;norm(t,Inf)];
    f12 = [f12;E(tau,eta)];
    f13 = [f13;cvx_optval];
end

for k=1:length(lambda1)
    cvx_begin sdp quiet
    cvx_solver sedumi
        variable tau1(n)
        variable eta1(n) 
        variable t1(n)
        variable s(1)
        minimize(norm(t1,Inf) + lambda1(k)*E(tau1,eta1))
        subject to
            t1 >= ones(n,1)*norm(tau1,Inf);
            t1 <= ones(n,1)*sum(tau1);
            tau1 >= alpha/s_max;
            tau1 <= alpha/s_min;
            eta1 <= s_max*(1./alpha);
            eta1 >= s_min*(1./alpha);
            s == alpha.*eta1;
            s >= s_min;
            s <= s_max;
            for j=1:m
                t1(P(j,1)) +  tau1(P(j,2)) - t1(P(j,2)) <= 0;
            end
            for i=1:n
            [[eta1(i), 1]; [1, tau1(i)]]>=0;
            [[s, sqrt(alpha(i))]; [sqrt(alpha(i)), tau1(i)]]>=0;
            end
    cvx_end
    f21 = [f21;norm(t1,Inf)];
    f22 = [f22;E(tau1,eta1)];
    f23 = [f23;cvx_optval];
end

figure(1)
plot(log(f11),log(f12))
title('T - E trade-off')
xlabel('T')
ylabel('E')
hold on
plot(log(f21), log(f22),'r--')
legend('different speed','constant speed','Location','northeast')

figure(2)
plot(lambda1, log(f13))
title('Optimal values for different lambda')
xlabel('lambda')
ylabel('T + lambda*E')
hold on
plot(lambda1, log(f23),'r--')
legend('different speed','constant speed','Location','southeast')

figure(3)
plot(lambda1, log(f23-f13))
title('Difference in optimal values between constant and different speed for differen lambda')
xlabel('lambda')
ylabel('delta(T + lambda*E)')